﻿Public Class Penyewa
    Public Property id_penyewa As String
    Public Property nama_penyewa As String
    Public Property telepon As String
    Public Property id_kamar As String
    Public Property harga As String
    Public Property tanggal_checkin As String
    Public Property tanggal_checkout As String
    Public Property jumlah_malam As String
    Public Property total_biaya As String

End Class
