﻿Public Class Users

    Public Property id As String
    Public Property username As String
    Public Property passwd As String
    Public Property rolename As String
End Class
