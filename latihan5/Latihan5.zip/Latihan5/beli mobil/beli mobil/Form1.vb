﻿Public Class Form1
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If (Val(txtPilihmobil.Text) >= 20) Then
            txtKeterangan.Text = "Mobil BMW"

        ElseIf (txtPilihmobil.Text >= 15) Then
            txtKeterangan.Text = "Mobil Ferari"

        ElseIf (txtPilihmobil.Text >= 10) Then
            txtKeterangan.Text = "Mobil Truk"

        ElseIf (txtPilihmobil.Text >= 5) Then
            txtKeterangan.Text = "Mobil Angkot"

        Else
            txtKeterangan.Text = "Maaf anda tidak dapat"
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
